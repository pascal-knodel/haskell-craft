--
-- Relevant definitions from chapter 4 for chapter 8 ...
--
module C'4 where



import Test.QuickCheck hiding ( Result )




-- Subchapter 4.3, Rock - Paper - Scissors ...


data Move

 =     Rock
    |  Paper
    |  Scissors
   
    deriving Eq


instance Show Move 

 where
 
 show Rock     =  "R"
 show Paper    =  "P"
 show Scissors =  "S"


instance Arbitrary Move

 where
 
 arbitrary =  elements [ Rock , Paper , Scissors ]


beat :: Move -> Move
beat Rock     = Paper
beat Paper    = Scissors
beat Scissors = Rock


lose :: Move -> Move
lose Rock  = Scissors
lose Paper = Rock
lose _     = Paper



-- Exercise 4.11.


data Result

 =     Win
    |  Lose
    |  Draw
   
    deriving Eq


instance Show Result 

 where
         
 show Win  = "W"
 show Lose = "L"
 show Draw = "D"



-- Exercise 4.12. ...


outcome :: Move -> Move -> Result
outcome firstPlayerMove secondPlayerMove

 |  firstPlayerMove == ( beat secondPlayerMove )  = Win
 |  firstPlayerMove == ( lose secondPlayerMove )  = Lose
 |                                     otherwise  = Draw   -- |  firstPlayerMove == secondPlayerMove =  Draw


