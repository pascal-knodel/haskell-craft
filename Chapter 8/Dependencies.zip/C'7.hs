--
-- Relevant definitions from chapter 7 for chapter 8 ...
--
module C'7 where



import Data.Char ( toLower , isLetter , isDigit )




-- Exercise 7.33. ...


isPalin :: String -> Bool
isPalin string

 =      string == ""
    ||  (opaqueString /= "" && reverse opaqueString == opaqueString)
 
 where
 
 opaqueString :: String
 opaqueString =  disregard string

 disregard :: String -> String
 disregard =  toSameCase . removePunctuation
 
 removePunctuation :: String -> String
 removePunctuation [] = []
 removePunctuation ( character : remainingCharacters )
 
  |  isNotPunctuation character  = character : removePunctuation remainingCharacters
  |  otherwise                   =             removePunctuation remainingCharacters
 
 isNotPunctuation :: Char -> Bool
 isNotPunctuation character
 
  =  isLetter character || isDigit character
 
 toSameCase :: String -> String
 toSameCase [] = []
 toSameCase (character : remainingCharacters)
 
  =  (toLower character) : (toSameCase remainingCharacters)



-- Exercise 7.12. ...


ins :: Integer -> [Integer] -> [Integer]
ins integer [] = [integer]
ins integer ( listInteger : remainingListIntegers )
 
 |  integer < listInteger  = integer     : (listInteger : remainingListIntegers)
 |  otherwise              = listInteger : (ins integer remainingListIntegers)




