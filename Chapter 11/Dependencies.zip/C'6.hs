--
-- Relevant definitions from chapter 6 for chapter 11 ...
--
module C'6 where



import Prelude hiding ( lookup )

import Data.List ( concat )




-- Subchapter 6.7 ...


type Name    =  String
type Price   =  Int
type BarCode =  Int

type Database =  [ ( BarCode , Name , Price ) ]


codeIndex :: Database
codeIndex =  [ 
               ( 4719 , "Fish Fingers"       , 121 ) ,
               ( 5643 , "Nappies"            , 1010) ,
               ( 3814 , "Orange Jelly"       , 56  ) ,
               ( 1111 , "Hula Hoops"         , 21  ) ,
               ( 1112 , "Hula Hoops (Giant)" , 133 ) ,
               ( 1234 , "Dry Sherry, 1lt"    , 540 )
             ]

              
type TillType =  [BarCode]
type BillType =  [ ( Name , Price ) ]


lineLength :: Int
lineLength =  30


-- ...



-- Exercise 6.39, "formatPence":


formatPence :: Price -> String
formatPence price

 |  isNegativePrice price  = error "Negative price."
 |  otherwise              = pounds ++ "." ++ pence
 
 where
 
 pounds :: String
 pounds =  show (price `div` 100)
 
 pence :: String
 pence =  let pence = (price `mod` 100) in 
          if  (isSingleDigit pence) then ( "0" ++ (show pence) )
                                    else (         show pence  )
 
 isSingleDigit :: Int -> Bool
 isSingleDigit int
 
  |  int <  10  = True
  |  otherwise  = False
 
 isNegativePrice :: Int -> Bool
 isNegativePrice int
  
  |  int < 0    = True
  |  otherwise  = False



-- Exercise 6.40, "formatLine":


formatLine :: (Name, Price) -> String
formatLine (name, price)

 =  name ++ dots ++ formattedPrice ++ "\n"
 
 where
 
 formattedPrice :: String
 formattedPrice =  formatPence price
 
 nonFillCharacterCount :: Int
 nonFillCharacterCount =  (length name) + (length formattedPrice) -- Definition: "\n" (white space) doesn't count.
 
 numberOfDots :: Int
 numberOfDots =  lineLength - nonFillCharacterCount
 
 dots :: String
 dots =  replicate numberOfDots '.'



-- Exercise 6.41, "formatLines":


formatLines :: [ (Name, Price) ] -> String
formatLines namePricePairs

 =  concat (map formatLine namePricePairs)



-- Exercisse 6.42, "makeTotal":


makeTotal :: BillType -> Price
makeTotal namePricePairs

 =  sum (map snd namePricePairs)



-- Exercise 6.43, "formatTotal":


formatTotal :: Price -> String
formatTotal price

 =  "\n" ++ ( formatLine ( "Total" , price ) )



-- Exercise 6.44, "formatBill":


formatBill :: BillType -> String
formatBill namePricePairs

 =      (formatTitle "Haskell Stores")
    ++  (formatLines namePricePairs)
    ++  ( formatTotal (makeTotal namePricePairs) )

   
formatTitle :: String -> String
formatTitle title

 =  "\n" ++ (center title lineLength) ++ "\n\n"


type LineLength =  Int

center :: String -> LineLength -> String
center string lineLength

 =  blanksLeft ++ string ++ blanksRight
 
 where
 
 blanksCount :: Int
 blanksCount =  lineLength - (length string)
 
 numberOfBlanksLeft, numberOfBlanksRight :: Int
 
 numberOfBlanksLeft  =  blanksCount `div` 2
 numberOfBlanksRight =  blanksCount - numberOfBlanksLeft
 
 blanksLeft, blanksRight :: String
 
 blanksLeft  =  replicate numberOfBlanksLeft  ' '
 blanksRight =  replicate numberOfBlanksRight ' '



-- Exercise 6.45, "look":


look :: Database -> BarCode -> (Name, Price)
look database indexBarCode

 |  searchResult == []  = ("Unknown Item", 0)
 |  otherwise           = head searchResult
 
 where
 
 searchResult :: [ (Name, Price) ]
 searchResult =  [ ( name , price ) | ( barCode , name , price ) <- database , barCode == indexBarCode ]



-- Exercise 6.46, "lookup":


-- Note: import Prelude hiding ( lookup )

lookup :: BarCode -> (Name, Price)
lookup barCode

 =  look codeIndex barCode   



-- Exercise 6.47, "makeBill":


makeBill :: TillType -> BillType
makeBill tillType

 =  map lookup tillType   -- Note: import Prelude hiding ( lookup )




